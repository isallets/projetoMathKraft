package com.example.mathkraft

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
